package com.example.solution_challange

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
